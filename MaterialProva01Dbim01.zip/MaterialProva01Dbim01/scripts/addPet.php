<?php
require_once '../funcoes/init.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$dataNascimento = isset($_POST['dataNascimento']) ? $_POST['dataNascimento'] : null;
$raca = isset($_POST['raca']) ? $_POST['raca'] : null;
if (empty($nome) || empty($dataNascimento) || empty($raca))
{
    echo "Volte e preencha todos os campos";
    exit;
}
$PDO = db_connect();
$sql = "INSERT INTO myPets(nomePet, dataNascimento, raca) VALUES(:nome, :dataNascimento, :raca)";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':dataNascimento', $dataNascimento);
$stmt->bindParam(':raca', $raca);

if ($stmt->execute())
{
    header('Location: ../html/msgSucesso.html');
}
else
{
    echo "Erro ao cadastrar";
    print_r($stmt->errorInfo());
}
?>